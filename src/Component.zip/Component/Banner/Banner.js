import React, { useState } from 'react';
import SignIn from '../SignIn/SignIn';
import JoinIn from '../JoinIn/JoinIn';
import inputImg from "../Image/input img.png"
import bannerImg from "../Image/bannerpeople.png"
import connectimg from "../Image/Connect With Separator.png"
import "../../App.css";

function Banner() {
    const [Sign, setSign] = useState(true)
    const [Join, setJoin] = useState(false)

    const handlesign = () => {
        setSign(true)
        setJoin(false)
    }

    const handlejoin = () => {
        setSign(false)
        setJoin(true)
    }
    return (
        <>
            <div className='Banner-background p-3'>
                <div className='container'>
                    <div className='row'>
                    <div className='col-lg-8 col-md-8 col-sm-12'>
                      <div></div>
                      <div>
                        <img src={bannerImg} alt/>
                      </div>
                    </div>
                    <div className='col-lg-4 col-md-4 col-sm-12'>
                        <div>
                            <button type="button" onClick={()=>handlesign()} className={`btn ${Sign ? 'btn-Sign' : "btn-Join"}`}>Primary</button>
                            <button type="button" onClick={()=>handlejoin()} className={`btn ${Join ? 'btn-Sign' : "btn-Join"}`}>Secondary</button>
                        </div>
                        <div>
                            <img src={inputImg} alt />
                        </div>
                        <div className='my-2'>
                            <img src={connectimg} alt />
                        </div>
                        {Sign && <SignIn />}
                        {Join && <JoinIn />}
                    </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Banner;